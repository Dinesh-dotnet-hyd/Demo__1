package ui;

import api.AdminResource;
import model.Customer;
import model.IRoom;
import model.Room;
import model.RoomType;
import model.FreeRoom;

import java.util.*;

public class AdminMenu {

	private static final AdminResource adminResource = AdminResource.getInstance();
	private static final Scanner scanner = new Scanner(System.in);

	public static void displayAdminMenu() {
		String option;
		do {
			System.out.println("\n--- ADMIN MENU ---");
			System.out.println("1. See all Customers");
			System.out.println("2. See all Rooms");
			System.out.println("3. See all Reservations");
			System.out.println("4. Add a Room");
			System.out.println("5. Back to Main Menu");
			System.out.print("Please select a number for the menu option: ");

			option = scanner.nextLine();

			switch (option) {
			case "1":
				seeAllCustomers();
				break;
			case "2":
				seeAllRooms();
				break;
			case "3":
				adminResource.displayAllReservations();
				break;
			case "4":
				addRoom();
				break;
			case "5":
				MainMenu.displayMainMenu();
				break;
			default:
				System.out.println("Invalid option. Please try again.");
			}
		} while (!option.equals("5"));
	}

	private static void seeAllCustomers() {
		Collection<Customer> customers = adminResource.getAllCustomers();
		if (customers.isEmpty()) {
			System.out.println("No customers found.");
		} else {
			customers.forEach(System.out::println);
		}
	}

	private static void seeAllRooms() {
		Collection<IRoom> rooms = adminResource.getAllRooms();
		if (rooms.isEmpty()) {
			System.out.println("No rooms found.");
		} else {
			rooms.forEach(System.out::println);
		}
	}

	private static void addRoom() {
    String addMore;
    do {
        String roomNumber = null;
        while (true) {
            System.out.print("Enter room number: ");
            String raw = scanner.nextLine();
            if (raw == null) {
                System.out.println("Room number cannot be empty. Please enter a valid room number.");
                continue;
            }
            raw = raw.trim();
            if (raw.length() >= 2 && ((raw.startsWith("\"") && raw.endsWith("\"")) || (raw.startsWith("'") && raw.endsWith("'")))) {
                raw = raw.substring(1, raw.length() - 1).trim();
            }
            if (raw.isEmpty()) {
                System.out.println("Room number cannot be empty or whitespace only. Please enter a valid room number.");
                continue;
            }
            roomNumber = raw;
            break;
        }

        Double price = null;
        while (price == null) {
            System.out.print("Enter room price per night (0 for free): ");
            String priceInput = scanner.nextLine().trim();
            try {
                if (priceInput.isEmpty()) {
                    System.out.println("Price cannot be empty. Please enter a numeric value.");
                    continue;
                }
                price = Double.parseDouble(priceInput);
                if (Double.isNaN(price) || Double.isInfinite(price)) {
                    System.out.println("Invalid number. Please enter a valid numeric value.");
                    price = null;
                    continue;
                }
                if (price < 0) {
                    System.out.println("Price cannot be negative. Please enter a non-negative value.");
                    price = null;
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid price. Please enter a valid numeric value (e.g., 150 or 0).");
                price = null;
            }
        }

        RoomType roomType = null;
        while (roomType == null) {
            System.out.print("Enter room type: 1 for SINGLE, 2 for DOUBLE: ");
            String t = scanner.nextLine().trim();
            if ("1".equals(t)) {
                roomType = RoomType.SINGLE;
            } else if ("2".equals(t)) {
                roomType = RoomType.DOUBLE;
            } else {
                System.out.println("Invalid selection. Enter 1 for SINGLE or 2 for DOUBLE.");
            }
        }

        IRoom room;
        if (price == 0.0) {
            room = new FreeRoom(roomNumber,0, roomType);
        } else {
            room = new Room(roomNumber, price, roomType);
        }

        try {
            adminResource.addRoom(Arrays.asList(room));
            System.out.println("Room added: " + room.getRoomNumber());
        } catch (IllegalArgumentException ex) {
            System.out.println("Could not add room: " + ex.getMessage());
        }

        System.out.print("Would you like to add another room? (y/n): ");
        addMore = scanner.nextLine().trim();
    } while (addMore.equalsIgnoreCase("y"));
}


}

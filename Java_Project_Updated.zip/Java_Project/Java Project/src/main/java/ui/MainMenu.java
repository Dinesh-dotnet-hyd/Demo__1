package ui;

import api.HotelResource;
import model.IRoom;
import model.Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainMenu {

    private static final HotelResource hotelResource = HotelResource.getInstance();
    private static final Scanner scanner = new Scanner(System.in);
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    static {
        dateFormat.setLenient(false); 
    }

    public static void main(String[] args) {
        displayMainMenu();
    }

    public static void displayMainMenu() {
        String option;
        do {
            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. Find and reserve a room");
            System.out.println("2. See my reservations");
            System.out.println("3. Create an account");
            System.out.println("4. Admin");
            System.out.println("5. Exit");
            System.out.print("Please select a number for the menu option: ");

            option = scanner.nextLine();

            switch (option) {
                case "1":
                    findAndReserveRoom();
                    break;
                case "2":
                    seeMyReservations();
                    break;
                case "3":
                    createAccount();
                    break;
                case "4":
                    AdminMenu.displayAdminMenu();
                    break;
                case "5":
                    System.out.println("Exiting application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid input. Please select a valid option.");
            }
        } while (!option.equals("5"));
    }

    private static void findAndReserveRoom() {
    System.out.print("Enter your email (format: name@domain.com): ");
    String email = scanner.nextLine().trim();

    Date checkInDate = null;
    Date checkOutDate = null;

    while (true) {
        try {
            System.out.print("Enter Check-In Date (dd/MM/yyyy): ");
            String inStr = scanner.nextLine().trim();
            checkInDate = dateFormat.parse(inStr);

            System.out.print("Enter Check-Out Date (dd/MM/yyyy): ");
            String outStr = scanner.nextLine().trim();
            checkOutDate = dateFormat.parse(outStr);
            break;
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please enter a valid dd/MM/yyyy date.");
        }
    }

    Date today = truncateTime(new Date());
    Date inNoTime = truncateTime(checkInDate);
    Date outNoTime = truncateTime(checkOutDate);

    if (inNoTime.before(today)) {
        System.out.println("Check-in date is in the past.");
        return;
    }

    if (!outNoTime.after(inNoTime)) {
        System.out.println("Check-out date must be after check-in date.");
        return;
    }

    Collection<IRoom> available = hotelResource.findARoom(checkInDate, checkOutDate);

    if (!available.isEmpty()) {
        System.out.println("Available Rooms:");
        for (IRoom r : available) {
            System.out.println(r);
        }

        System.out.print("Would you like to book a room? (y/n): ");
        String resp = scanner.nextLine().trim();

        if (resp.equalsIgnoreCase("y")) {
            System.out.print("Enter room number: ");
            String roomNumber = scanner.nextLine().trim();
            IRoom chosen = null;

            for (IRoom r : available) {
                if (r.getRoomNumber().equals(roomNumber)) {
                    chosen = r;
                    break;
                }
            }

            if (chosen == null) {
                System.out.println("Invalid room number.");
                return;
            }

            hotelResource.bookARoom(email, chosen, checkInDate, checkOutDate);
            System.out.println("Room booked successfully!");
        }
        return;
    }

    System.out.println("No rooms available for the selected dates.");

    Calendar cal = Calendar.getInstance();
    cal.setTime(checkInDate);
    cal.add(Calendar.DATE, 7);
    Date altCheckIn = cal.getTime();

    cal.setTime(checkOutDate);
    cal.add(Calendar.DATE, 7);
    Date altCheckOut = cal.getTime();

    Collection<IRoom> altAvailable = hotelResource.findARoom(altCheckIn, altCheckOut);

    if (!altAvailable.isEmpty()) {
        System.out.println("Recommended Rooms for alternate dates (" +
                dateFormat.format(altCheckIn) + " to " + dateFormat.format(altCheckOut) + "):");

        for (IRoom r : altAvailable) {
            System.out.println(r);
        }

        System.out.print("Would you like to book a recommended room? (y/n): ");
        String resp = scanner.nextLine().trim();

        if (resp.equalsIgnoreCase("y")) {
            System.out.print("Enter room number: ");
            String roomNumber = scanner.nextLine().trim();
            IRoom chosen = null;

            for (IRoom r : altAvailable) {
                if (r.getRoomNumber().equals(roomNumber)) {
                    chosen = r;
                    break;
                }
            }

            if (chosen == null) {
                System.out.println("Invalid room number.");
                return;
            }

            hotelResource.bookARoom(email, chosen, altCheckIn, altCheckOut);
            System.out.println("Room booked successfully for alternate dates!");
        }
        return;
    }

    System.out.println("No rooms available even for alternate (+7 days) dates.");
}

    private static Date truncateTime(Date d) {
    Calendar cal = Calendar.getInstance();
    cal.setTime(d);
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);
    return cal.getTime();
}


    private static void seeMyReservations() {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();

        Collection<Reservation> reservations = hotelResource.getCustomersReservations(email);

        if (reservations == null || reservations.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            for (Reservation reservation : reservations) {
                System.out.println(reservation);
            }
        }
    }

    private static void createAccount() {
        System.out.print("Enter Email (name@domain.com): ");
        String email = scanner.nextLine();

        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        try {
            hotelResource.createACustomer(email, firstName, lastName);
            System.out.println("Account created successfully!");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid email format. Please try again.");
        }
    }
}



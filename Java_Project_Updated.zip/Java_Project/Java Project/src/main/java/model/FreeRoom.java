package model;

public class FreeRoom extends Room {

    public FreeRoom(String roomNumber, double p, RoomType roomType) {
        super(roomNumber, p, roomType);
    }

    @Override
    public boolean isFree() {
        return true;
    }

    @Override
    public String toString() {
        //String displayPrice = (getRoomPrice() == 0.0) ? "Free" : "$" + getRoomPrice();
        return "Room Number: " + getRoomNumber() + ", Type: " + getRoomType() + ", Price: " + getRoomPrice()+ " (FreeRoom)";
    }
}

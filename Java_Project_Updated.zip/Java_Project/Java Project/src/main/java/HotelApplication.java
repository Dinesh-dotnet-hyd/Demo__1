import api.AdminResource;
import model.FreeRoom;
import model.IRoom;
import model.RoomType;

import java.util.Arrays;

public class HotelApplication {
    public static void main(String[] args) {
        IRoom freeRoom = new FreeRoom("105", 10.00,RoomType.SINGLE);
        AdminResource admin = AdminResource.getInstance();  
        admin.addRoom(Arrays.asList(freeRoom));

        System.out.println("Welcome to the Hotel Reservation Application!");
        ui.MainMenu.displayMainMenu();
    }
}

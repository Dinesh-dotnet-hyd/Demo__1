import ui.MainMenu;

public class HotelApplication {
    public static void main(String[] args) {
        System.out.println("Welcome to the Hotel Reservation Application!");
        MainMenu.displayMainMenu();
    }
}
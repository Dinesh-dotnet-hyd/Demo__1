import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const[form, setForm]=useState({
    email:"",
    password:""
  });
  function handleChange(e){
    setForm({...form, [e.target.name]:e.target.value});
  }
  function Validate(e){
    if(form.email=="dinesh@gmail.com"&& form.password=="1234"){
      alert("Valid")
    }
    else{
      alert("Invalid")
    }
  }
  return (
    <>
      <form>
        <lable>Name</lable>
        <input name='email' onChange={handleChange}/>
        <br/>
        <lable>Password</lable>
        <input name='password' onChange={handleChange}/> 
        <br/>
        <button onClick={Validate}>Submit</button>
      </form>
    </>
  )
}

export default App
